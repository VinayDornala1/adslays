
class APIConstant
{

  static String base_url='http://app.stormoverseas.com/API/';


}
